from transformers import AutoModelForImageClassification, AutoProcessor

# Local folder where model files will be saved
cache_dir = "./ai-image-detector-model2"

# Download and save the model + preprocessor
AutoModelForImageClassification.from_pretrained("Ateeqq/ai-vs-human-image-detector", cache_dir=cache_dir)
AutoProcessor.from_pretrained("Ateeqq/ai-vs-human-image-detector", cache_dir=cache_dir)

print("✅ Model downloaded to", cache_dir)
