from transformers import AutoModelForImageClassification, AutoImageProcessor
from PIL import Image
import torch
import os

# Path to the downloaded model
model_path = "./ai-image-detector-model2/models--Ateeqq--ai-vs-human-image-detector/snapshots"

# Find the actual snapshot folder (usually only one)
snapshot_dir = os.path.join(model_path, os.listdir(model_path)[0])

# Load model and processor
model = AutoModelForImageClassification.from_pretrained(snapshot_dir)
processor = AutoImageProcessor.from_pretrained(snapshot_dir, use_fast=True)

# Load your test image
image = Image.open("WhatsApp Image 2025-07-09 at 02.14.57_0a075d29.jpg").convert("RGB")  # make sure the image exists in your folder

# Preprocess and run inference
inputs = processor(images=image, return_tensors="pt")
with torch.no_grad():
    outputs = model(**inputs)
    probs = torch.nn.functional.softmax(outputs.logits, dim=-1)

# Interpret result
labels = model.config.id2label
result = {labels[i]: float(p) for i, p in enumerate(probs[0])}

print("🧠 Prediction:", result)
